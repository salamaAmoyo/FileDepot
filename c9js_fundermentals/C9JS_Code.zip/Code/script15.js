$(function() {

  //$('#first').addClass('highlight');

  //$('p').addClass('highlight');

  //$('.chosen').addClass('highlight');

  //$('#first, .chosen').addClass('highlight');

  //$('li:even').addClass('highlight');

  //$('li:contains("Three")').addClass('highlight');

  //$('li:contains("Three")').next().addClass('highlight');
  
  //$('li:contains("Three")').siblings().addClass('highlight');

  //$('li:nth-child(2)').addClass('highlight');

  //$('p[name="mySecondPara"]').addClass('highlight');

  //$('p[name!="mySecondPara"]').addClass('highlight');

  //$('p').not('[name]').addClass('highlight');

  $(':header').addClass('highlight');


});








