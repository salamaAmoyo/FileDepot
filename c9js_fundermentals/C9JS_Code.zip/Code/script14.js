$(function() {

  //$("#title").text("Yay, I can get at the H1 immediately!");
  //$("#first").html("<h2>Great quotes</h2>");

  //$("#first").prepend("<h2>Great quotes</h2>");
  //$("#first").append("<h3>... for you to ponder ...</h3>");

  //alert($("#myAnchor").attr("href"));
  //$("#myAnchor").attr("href", "http://channel9.msdn.com");

  $("#title").addClass("standout").text("Chain of fools");

});

